import express from "express";
import path from "path";
import axios from "axios";
import { createServer as createViteServer } from "vite";

import pLimit from "p-limit";

const proxyLimiter = pLimit(3);

/**
 * ScraperAPI logic for protected domains
 */
async function fetchWithScraperAPI(url: string, headers: any, isManifest: boolean) {
  const apiKey = process.env.SCRAPER_API_KEY;
  if (!apiKey) throw new Error("SCRAPER_API_KEY not configured");

  // Logic for premium/protected domains
  const lowUrl = url.toLowerCase();
  const premiumDomains = ['peachify', 'eat-peach', 'vidsrc', 'embed.su', 'megacloud', 'vizcloud'];
  const isPremium = premiumDomains.some(domain => lowUrl.includes(domain));
  
  // Ultra premium for extreme cases (Cloudflare/DDoS guards)
  const isUltraPremium = lowUrl.includes('eat-peach.sbs') || lowUrl.includes('usa.eat-peach');

  let scraperUrl = url;
  
  if (url.includes('api.scraperapi.com')) {
    // If it's already a ScraperAPI URL, just augment it
    const urlObj = new URL(url);
    if (isUltraPremium) {
      urlObj.searchParams.set('premium', 'true');
      urlObj.searchParams.set('ultra_premium', 'true');
      urlObj.searchParams.set('render', 'true');
    } else if (isPremium) {
      urlObj.searchParams.set('premium', 'true');
      urlObj.searchParams.set('render', 'false');
    }
    scraperUrl = urlObj.toString();
  } else {
    // Otherwise wrap it
    scraperUrl = `http://api.scraperapi.com?api_key=${apiKey}&url=${encodeURIComponent(url)}`;
    if (isUltraPremium) {
      scraperUrl += '&premium=true&ultra_premium=true&render=true';
    } else if (isPremium) {
      scraperUrl += '&premium=true&render=false';
    }
  }

  return axios.get(scraperUrl, {
    headers: {
      ...headers,
      'Accept-Encoding': 'identity',
    },
    responseType: isManifest ? 'text' : 'stream',
    timeout: 60000,
    validateStatus: () => true
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Add global CORS headers
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS, POST');
    res.setHeader('Access-Control-Allow-Headers', '*');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  // CORS Proxy Endpoint
  // Usage: /api/proxy?url=HTTPS_URL_TO_PROXY
  app.get("/api/proxy", async (req, res) => {
    const targetUrl = req.query.url as string;
    const customReferer = req.query.referer as string;
    const customUA = req.query.userAgent as string;

    if (!targetUrl) {
      return res.status(400).send("URL parameter is required");
    }

    // Wrap proxy logic in global limiter to prevent rate-limiting on target sites
    return proxyLimiter(async () => {
      // Determine if it's a manifest early for error logging logic
      const lowTarget = targetUrl.toLowerCase();
      const isManifest = lowTarget.includes('.m3u8') || 
                        lowTarget.includes('.mpd') ||
                        (targetUrl.includes('data=') && lowTarget.includes('%2em3u8'));

      try {
        const urlObj = new URL(targetUrl);
        const headers: Record<string, string> = {
          'User-Agent': customUA || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          'Accept': '*/*',
          'Accept-Language': 'en-US,en;q=0.9',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache',
        };

        // Set Referer and Origin to match the target to bypass some security checks
        headers['Referer'] = customReferer || urlObj.origin + '/';
        headers['Origin'] = urlObj.origin;

        // Handle X-Requested-With which is often used to block bot traffic
        headers['X-Requested-With'] = 'XMLHttpRequest';

        // Check if we should use ScraperAPI fallback for known problematic domains
        const useScraper = process.env.SCRAPER_API_KEY && (
          targetUrl.includes('peachify') || 
          targetUrl.includes('eat-peach') || 
          targetUrl.includes('vidsrc') ||
          targetUrl.includes('embed.su') ||
          targetUrl.includes('megacloud') ||
          targetUrl.includes('vizcloud') ||
          targetUrl.includes('rabbitstream') ||
          targetUrl.includes('cf-vod') || 
          customUA?.includes('ScraperAPI') ||
          customReferer?.includes('ScraperAPI')
        );

        // Determine if it's a manifest or segment
        let response;
        if (useScraper) {
          response = await fetchWithScraperAPI(targetUrl, headers, isManifest);
        } else {
          // Normal proxy
          response = await axios({
            method: 'get',
            url: targetUrl,
            headers: isManifest ? headers : { ...headers, ...(req.headers.range ? { 'Range': req.headers.range } : {}) },
            responseType: isManifest ? 'text' : 'stream',
            timeout: isManifest ? 15000 : 30000,
            validateStatus: () => true
          });
        }

        if (response.status >= 400) {
          // Log errors sparingly or not at all for segment failures to avoid log bombardment
          if (isManifest) {
            console.error(`Proxy Target Error (${response.status}): ${targetUrl}`);
          }
          return res.status(response.status).send(`Target server returned ${response.status}`);
        }

        if (isManifest) {
          let content = response.data;
          
          // Accurate base URL calculation (ignores query params)
          const pathOnly = targetUrl.split('?')[0];
          const baseUrl = pathOnly.substring(0, pathOnly.lastIndexOf('/') + 1);
          
          // Build the segment proxy prefix with preserved headers
          let segmentProxyPrefix = `/api/proxy?`;
          if (customReferer) segmentProxyPrefix += `referer=${encodeURIComponent(customReferer)}&`;
          if (customUA) segmentProxyPrefix += `userAgent=${encodeURIComponent(customUA)}&`;
          segmentProxyPrefix += `url=`;

          // Robust manifest rewriter for HLS
          const lines = content.split('\n');
          const rewrittenLines = lines.map((line: string) => {
            const trimmed = line.trim();
            if (!trimmed) return line;
            
            // Handle tags with URLs (like URI="...")
            if (trimmed.startsWith('#')) {
              return line.replace(/URI=["']([^"']+)["']/g, (match, p1) => {
                let fullUrl = p1;
                if (!p1.startsWith('http')) {
                  if (p1.startsWith('/')) {
                    fullUrl = urlObj.origin + p1;
                  } else {
                    fullUrl = baseUrl + p1;
                  }
                }
                return `URI="${segmentProxyPrefix}${encodeURIComponent(fullUrl)}"`;
              });
            }
            
            // Handle direct URLs
            let fullUrl = trimmed;
            if (!trimmed.startsWith('http')) {
              if (trimmed.startsWith('/')) {
                fullUrl = urlObj.origin + trimmed;
              } else {
                fullUrl = baseUrl + trimmed;
              }
            }
            return `${segmentProxyPrefix}${encodeURIComponent(fullUrl)}`;
          });
          
          content = rewrittenLines.join('\n');

          const contentType = response.headers['content-type'] || 'application/vnd.apple.mpegurl';
          res.setHeader('Content-Type', contentType);
          return res.send(content);
        } else {
          // Stream binary data directly (segments)
          // Copy relevant headers back to client
          const responseHeaders = [
            'content-type',
            'content-length',
            'content-range',
            'accept-ranges',
            'cache-control'
          ];

          responseHeaders.forEach(h => {
            if (response.headers[h]) {
              res.setHeader(h, response.headers[h]);
            }
          });

          // Set status code from target (important for 206 Partial Content)
          res.status(response.status);
          
          // Handle ScraperAPI vs Direct stream
          if (useScraper) {
            // ScraperAPI might not support streaming well if it's been converted to text or has headers
            return res.send(response.data);
          } else {
            response.data.pipe(res);
            response.data.on('error', (err: any) => {
              // Minimal logging for stream errors
              res.end();
            });
          }
        }
      } catch (error: any) {
        // Only log serious failures, not every skipped segment or timeout
        if (isManifest) {
          console.error("Proxy failure:", error.message, "-", targetUrl);
        }
        if (!res.headersSent) {
          res.status(502).send("Proxy Bridge Failure: " + error.message);
        }
      }
    });
});

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
