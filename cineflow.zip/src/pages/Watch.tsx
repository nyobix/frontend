import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { tmdb, scraper, getImageUrl, SCRAPER_BASE_URL } from '../services/api';
import { MovieDetails, Movie } from '../lib/utils';
import { Star, Clock, Calendar, Play, ChevronLeft, Share2, Plus, Info, Layers, Wifi, Cpu } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import VideoPlayer from '../components/VideoPlayer';
import { motion } from 'motion/react';
import { useExtension } from '../hooks/useExtension';
import { useStream } from '../context/StreamContext';

export default function Watch() {
  const { type, id } = useParams<{ type: 'movie' | 'tv'; id: string }>();
  
  const {
    isExtensionActive,
    isScraping: isExtensionScraping,
    scrapedSources,
    scrapeError: extensionScrapeError,
    triggerExtensionScrape
  } = useExtension();

  const {
    setIsActive,
    setCurrentType,
    setCurrentId,
    setTitle,
    providers,
    activeProvider: provider,
    setActiveProvider: setProvider,
    sources,
    setSources,
    activeSource,
    setActiveSource,
    season,
    setSeason,
    episode,
    setEpisode,
    setTotalSeasons
  } = useStream();

  const [details, setDetails] = useState<MovieDetails | null>(null);
  const [recommendations, setRecommendations] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingSources, setLoadingSources] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasAutoSelected, setHasAutoSelected] = useState(false);

  useEffect(() => {
    setIsActive(true);
    if (type) setCurrentType(type);
    if (id) setCurrentId(id);
    return () => {
      setIsActive(false);
      setCurrentType(null);
      setCurrentId(null);
      setTitle('');
    };
  }, [type, id, setIsActive, setCurrentType, setCurrentId, setTitle]);

  useEffect(() => {
    if (details) {
      setTitle(details.title || details.name || '');
      setTotalSeasons(details.number_of_seasons || 1);
    }
  }, [details, setTitle, setTotalSeasons]);

  useEffect(() => {
    setHasAutoSelected(false);
  }, [id]);

  useEffect(() => {
    const fetchData = async () => {
      if (!type || !id) return;
      if (!details) setLoading(true);
      setError(null);
      
      try {
        const [detailsRes, recsRes] = await Promise.all([
          tmdb.getDetails(type, id),
          tmdb.getRecommendations(type, id),
        ]);
        
        const movieDetails = detailsRes.data;
        setDetails(movieDetails);
        setRecommendations(recsRes.data.results);
        window.scrollTo(0, 0);

        // Auto-select provider based on genres/type
        if (!hasAutoSelected) {
          const genres = movieDetails.genres.map((g: any) => g.name.toLowerCase());
          const isAnime = genres.includes('animation') && 
                         (movieDetails.original_language === 'ja' || genres.includes('anime'));
          const isDrama = genres.includes('drama') && 
                         ['ko', 'zh', 'ja'].includes(movieDetails.original_language);

          let newProvider = 'vidsrc';
          if (isAnime) newProvider = 'vidsrc'; // Most of these support multi-genre
          else if (isDrama) newProvider = 'vixsrc';
          
          setHasAutoSelected(true);
          if (newProvider !== provider) {
            setProvider(newProvider);
            return;
          }
        }

        setLoadingSources(true);
        
        // Fetch sources based on type
        let sourcesResult;
        if (type === 'movie') {
          sourcesResult = await scraper.getMovieSources(id);
        } else {
          sourcesResult = await scraper.getTvSources(id, season, episode);
        }

        if (sourcesResult.error) {
          throw new Error(sourcesResult.error.error.message);
        }

        const data = sourcesResult.data;
        if (data?.sources?.length > 0) {
          const allSources = data.sources.map((s: any) => {
            let finalUrl = s.url;
            
            // 1. Fix localhost placeholders from backend
            if (finalUrl.includes('localhost') && SCRAPER_BASE_URL) {
              finalUrl = finalUrl.replace(/http:\/\/localhost:\d+/, SCRAPER_BASE_URL);
            }
            
            // 2. If it's still a direct URL (not hitting Railway/Backend), wrap it
            if (finalUrl.startsWith('http') && SCRAPER_BASE_URL && !finalUrl.includes(SCRAPER_BASE_URL)) {
               finalUrl = scraper.getProxiedUrl(finalUrl, s.headers);
            }
            
            return { ...s, url: finalUrl };
          });
          setSources(allSources);
          
          // Try to find source for current provider
          const providerSources = allSources.filter((s: any) => 
            s.provider?.id?.toLowerCase() === provider.toLowerCase() || 
            s.provider?.name?.toLowerCase() === provider.toLowerCase()
          );
          
          if (providerSources.length > 0) {
            setActiveSource(providerSources[0]);
          } else {
            setActiveSource(allSources[0]);
            // Update provider state to match the actually selected source
            const actualProvider = allSources[0].provider?.id?.toLowerCase() || 
                                  allSources[0].provider?.name?.toLowerCase() || 
                                  provider;
            setProvider(actualProvider);
          }
        } else {
          // If server returned no streams, trigger extension if installed/active!
          if (isExtensionActive) {
            setError(null);
            triggerExtensionScrape(type, id, movieDetails.title || movieDetails.name, season, episode);
          } else {
            setError(`No cached streams found on server. Try another provider, or activate the CinePro browser extension for immediate residential scraping.`);
          }
        }
      } catch (err: any) {
        console.error('Extraction error:', err.message || err);
        if (isExtensionActive) {
          setError(null);
          const finalTitle = details?.title || details?.name || 'Item';
          triggerExtensionScrape(type, id, finalTitle, season, episode);
        } else {
          const status = err.response?.status;
          setError(`Source unavailable (${status || 'Network Error'}). Please try another server or activate the CinePro extension.`);
        }
      } finally {
        setLoading(false);
        setLoadingSources(false);
      }
    };

    fetchData();
  }, [type, id, provider, season, episode, isExtensionActive]);

  // Sync scraped sources from extension to local state
  useEffect(() => {
    if (scrapedSources && scrapedSources.length > 0) {
      const allSources = scrapedSources.map((s: any) => {
        let finalUrl = s.url;
        
        // 1. Fix localhost placeholders
        if (finalUrl.includes('localhost') && SCRAPER_BASE_URL) {
          finalUrl = finalUrl.replace(/http:\/\/localhost:\d+/, SCRAPER_BASE_URL);
        }
        
        // 2. If it's still a direct URL, wrap it
        if (finalUrl.startsWith('http') && SCRAPER_BASE_URL && !finalUrl.includes(SCRAPER_BASE_URL)) {
          finalUrl = scraper.getProxiedUrl(finalUrl, s.headers);
        }
        
        return { ...s, url: finalUrl, isExtension: true };
      });
      
      setSources(allSources);
      setActiveSource(allSources[0]);
      setError(null);
    }
  }, [scrapedSources]);

  // Sync extension scraping error to component state
  useEffect(() => {
    if (extensionScrapeError) {
      setError(`Extension Scraping Error: ${extensionScrapeError}`);
    }
  }, [extensionScrapeError]);

  if (loading && !details) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!details) return null;

  return (
    <div className="min-h-screen bg-[#050505] text-white pt-24 pb-20">
      <div className="max-w-[1600px] mx-auto px-6 md:px-12">
        <div className="flex items-center justify-between mb-10">
          <Link to="/" className="group inline-flex items-center gap-3 text-zinc-500 hover:text-white transition-all">
            <div className="w-10 h-10 rounded-full bg-zinc-900 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-all">
              <ChevronLeft className="w-6 h-6" />
            </div>
            <span className="font-black uppercase tracking-widest text-sm italic">Back to Cinema</span>
          </Link>
          
          <div className="flex items-center gap-4">
            <button className="flex items-center gap-2 px-6 py-2.5 bg-zinc-900 border border-white/5 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-zinc-800 transition-all">
              <Plus className="w-4 h-4" /> Watchlist
            </button>
            <button className="flex items-center gap-2 px-6 py-2.5 bg-zinc-900 border border-white/5 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-zinc-800 transition-all">
              <Share2 className="w-4 h-4" /> Share
            </button>
          </div>
        </div>

        <div className="grid lg:grid-cols-12 gap-12">
          {/* Main Content Area */}
          <div className="lg:col-span-9 space-y-10">
            {/* Player Container */}
            <div className="relative aspect-video bg-zinc-900 rounded-[3rem] overflow-hidden shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] border border-white/5">
              {loadingSources && (
                <div className="absolute inset-0 z-10 bg-black/80 backdrop-blur-xl flex flex-col items-center justify-center">
                  <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-6"></div>
                  <p className="text-sm font-black uppercase italic tracking-widest text-zinc-400 animate-pulse">Inspecting Redis Cache & Core Scraper...</p>
                </div>
              )}

              {isExtensionScraping && (
                <div className="absolute inset-0 z-10 bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center p-8 text-center">
                  <div className="max-w-md space-y-6">
                    <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <div className="space-y-2">
                      <span className="px-3.5 py-1.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[9px] font-black uppercase tracking-widest rounded-full italic animate-pulse inline-flex items-center gap-1.5">
                        <Wifi className="w-3.5 h-3.5 text-indigo-400" /> Residential IP Extraction Active
                      </span>
                      <h3 className="text-2xl font-black uppercase italic tracking-tighter text-white">Browser Scraping Pipeline</h3>
                      <p className="text-zinc-500 text-xs font-bold uppercase tracking-widest leading-relaxed max-w-sm">
                        CinePro browser extension is searching provider hosts using your local network context to bypass data center blocks...
                      </p>
                    </div>

                    <div className="flex items-center justify-center gap-6 text-zinc-600 text-[10px] uppercase font-black tracking-widest">
                      <div className="flex items-center gap-2 text-indigo-400/80">
                        <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping"></span>
                        1. Fetching Providers
                      </div>
                      <div className="flex items-center gap-2">
                        <span>•</span>
                        2. Resolving Formats
                      </div>
                      <div className="flex items-center gap-2">
                        <span>•</span>
                        3. Saving to Redis
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {activeSource ? (
                <VideoPlayer 
                  url={activeSource.url} 
                  type={activeSource.type}
                  poster={getImageUrl(details.backdrop_path, 'original')} 
                />
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#050505]/95 backdrop-blur-md p-8 text-center">
                  <div className="max-w-md space-y-6">
                    <div className="mx-auto w-16 h-16 bg-zinc-900 border border-white/10 rounded-full flex items-center justify-center relative">
                      <Wifi className="w-8 h-8 text-indigo-500 animate-pulse" />
                      <span className="absolute -top-1 -right-1 flex h-4 w-4">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-4 w-4 bg-indigo-500 text-[9px] font-black items-center justify-center">!</span>
                      </span>
                    </div>
                    <div>
                      <h3 className="text-2xl font-black uppercase italic tracking-tighter mb-2 text-white">Redis Cache Miss / Server Block</h3>
                      <p className="text-zinc-500 text-xs font-bold uppercase tracking-wider leading-relaxed">
                        The raw server-side scraper was blocked or has no active cache for this release. Avoid broken streams by utilizing our Distributed Workforce.
                      </p>
                    </div>

                    <div className="p-5 bg-indigo-600/5 rounded-[2rem] border border-indigo-500/10 text-left space-y-3">
                      <h4 className="text-xs font-black text-indigo-400 uppercase tracking-widest flex items-center gap-2">🔌 Supercharge with CinePro Companion</h4>
                      <ul className="text-[10px] text-zinc-400 font-bold uppercase tracking-wide leading-relaxed space-y-1">
                        <li className="flex items-center gap-1.5"><span className="text-indigo-500">•</span> Scrapes direct on your computer (100% legal)</li>
                        <li className="flex items-center gap-1.5"><span className="text-indigo-500">•</span> Leverages safe, residential home IP address</li>
                        <li className="flex items-center gap-1.5"><span className="text-indigo-500">•</span> Completely bypasses Cloudflare, CORS and DDoS shields</li>
                        <li className="flex items-center gap-1.5"><span className="text-indigo-500">•</span> Saves stream links back to our Redis cache automatically!</li>
                      </ul>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                      <a 
                        href="https://github.com/cinepro-org/extension" 
                        target="_blank" 
                        rel="noreferrer noopener"
                        className="px-6 py-3 bg-indigo-600 text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-indigo-500 transition-all shadow-[0_10px_20px_rgba(79,70,229,0.3)] w-full sm:w-auto text-center"
                      >
                        Install Chrome Extension
                      </a>
                      <button 
                        onClick={() => window.location.reload()}
                        className="px-6 py-3 bg-zinc-900 border border-white/5 rounded-2xl text-xs font-black uppercase tracking-widest text-zinc-400 hover:text-white hover:bg-zinc-800 transition-all w-full sm:w-auto text-center"
                      >
                        Retry Server Scraper
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* TV Show Series Controls */}
            {type === 'tv' && (
              <div className="bg-zinc-900/40 border border-white/5 p-8 rounded-[2.5rem] backdrop-blur-2xl">
                <div className="flex items-center gap-3 mb-6">
                  <Play className="w-5 h-5 text-indigo-500 font-black" />
                  <h2 className="text-sm font-black uppercase tracking-[0.2em] italic">Series Controls</h2>
                </div>
                <div className="flex flex-wrap gap-6">
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-zinc-600">Season</label>
                    <select 
                      value={season}
                      onChange={(e) => {
                        setSeason(parseInt(e.target.value));
                        setEpisode(1);
                      }}
                      className="bg-zinc-800 border border-white/5 rounded-xl px-4 py-2 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    >
                      {Array.from({ length: details.number_of_seasons || 1 }, (_, i) => (
                        <option key={i + 1} value={i + 1}>Season {i + 1}</option>
                      ))}
                    </select>
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-zinc-600">Episode</label>
                    <div className="flex items-center gap-2">
                      <input 
                        type="number"
                        min="1"
                        value={episode}
                        onChange={(e) => setEpisode(parseInt(e.target.value) || 1)}
                        className="w-24 bg-zinc-800 border border-white/5 rounded-xl px-4 py-2 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-indigo-600"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Server Controls */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-zinc-900/40 border border-white/5 p-8 rounded-[2.5rem] backdrop-blur-2xl">
                <div className="flex items-center gap-3 mb-6">
                  <Layers className="w-5 h-5 text-indigo-500" />
                  <h2 className="text-sm font-black uppercase tracking-[0.2em] italic">Streaming Sources</h2>
                </div>
                
                {/* Provider Tabs */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {providers.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => setProvider(p.id)}
                      className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                        provider === p.id 
                          ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' 
                          : 'bg-white/5 text-zinc-500 hover:bg-white/10 hover:text-zinc-300'
                      }`}
                    >
                      <span className="mr-2">{p.icon}</span>
                      {p.name}
                    </button>
                  ))}
                </div>

                <div className="flex flex-col gap-3">
                  <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest italic mb-2">
                    Current Provider: <span className="text-indigo-500">{providers.find(p => p.id === provider)?.name || provider}</span>
                  </p>
                  <p className="text-zinc-600 text-[9px] font-bold uppercase tracking-tighter leading-relaxed">
                    Select a provider from the tabs above to request new stream sources from the backend.
                  </p>
                </div>
              </div>

              <div className="bg-zinc-900/40 border border-white/5 p-8 rounded-[2.5rem] backdrop-blur-2xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-6">
                    <Info className="w-5 h-5 text-indigo-500" />
                    <h3 className="text-sm font-black uppercase tracking-[0.2em] italic">Playback Info</h3>
                  </div>
                  <p className="text-zinc-500 text-xs leading-relaxed font-bold uppercase tracking-wider">
                    All streams are extracted in real-time from your private cloud infrastructure. If a quality is slow, please try another provider.
                  </p>
                </div>
                
                {sources.length > 0 && (
                  <div className="mt-8 space-y-4">
                    <span className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-600 block">Direct CDN Qualities:</span>
                    <div className="flex flex-wrap gap-2">
                      {sources.map((s, i) => (
                        <button
                          key={i}
                          onClick={() => setActiveSource(s)}
                          className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-tighter transition-all flex items-center gap-1.5 ${
                            activeSource?.url === s.url ? 'bg-indigo-600 text-white' : 'bg-white/5 text-zinc-500 hover:bg-white/10'
                          }`}
                        >
                          {s.isExtension && <Wifi className="w-3 h-3 text-emerald-400" />}
                          {s.quality || 'Auto'} {s.isExtension ? '📡' : ''}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Metadata Section */}
            <div className="bg-zinc-900/20 border border-white/5 p-12 rounded-[3.5rem] space-y-8">
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-white/5">
                <div>
                  <h1 className="text-5xl md:text-7xl font-black tracking-tighter uppercase italic leading-[0.9] text-white">
                    {details.title || details.name}
                  </h1>
                  <div className="flex flex-wrap items-center gap-6 mt-6">
                    <span className="flex items-center gap-2 text-yellow-500 font-black italic">
                      <Star className="w-5 h-5 fill-yellow-500" />
                      {details.vote_average.toFixed(1)}
                    </span>
                    <span className="w-1.5 h-1.5 rounded-full bg-zinc-800" />
                    <span className="text-zinc-400 font-bold uppercase tracking-widest text-sm">{new Date(details.release_date || details.first_air_date || '').getFullYear()}</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-zinc-800" />
                    <span className="bg-indigo-500/10 text-indigo-500 px-3 py-1 rounded-lg border border-indigo-500/20 text-xs font-black uppercase tracking-widest">{type}</span>
                  </div>
                </div>
              </div>
              
              <div className="grid md:grid-cols-3 gap-12">
                <div className="md:col-span-2">
                  <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-600 mb-6">The Story</h3>
                  <p className="text-xl text-zinc-400 font-medium leading-[1.6] italic">
                    {details.overview}
                  </p>
                </div>
                <div>
                  <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-600 mb-6">Categories</h3>
                  <div className="flex flex-wrap gap-2">
                    {details.genres.map((g) => (
                      <span key={g.id} className="px-4 py-2 bg-zinc-900 border border-white/5 rounded-xl text-xs font-black uppercase tracking-tighter text-zinc-400">
                        {g.name}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar / Recommendations */}
          <div className="lg:col-span-3 space-y-10">
            <div>
              <h2 className="text-sm font-black text-indigo-500 uppercase tracking-[0.3em] mb-3">Encore</h2>
              <h3 className="text-3xl font-black text-white tracking-tighter italic uppercase">You <span className="text-zinc-600">Might Like</span></h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-8">
              {recommendations.slice(0, 8).map((movie, i) => (
                <MovieCard key={movie.id} movie={{ ...movie, media_type: type }} index={i} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
