import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { tmdb } from '../services/api';
import { Movie } from '../lib/utils';
import MovieCard from '../components/MovieCard';
import { Search as SearchIcon } from 'lucide-react';

export default function Search() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [results, setResults] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchResults = async () => {
      if (!query) return;
      setLoading(true);
      try {
        const res = await tmdb.search(query);
        setResults(res.data.results.filter((r: any) => r.media_type !== 'person'));
      } catch (error) {
        console.error('Search error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchResults();
  }, [query]);

  return (
    <div className="min-h-screen bg-[#050505] text-white pt-32 pb-20">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-20">
          <div>
            <h1 className="text-sm font-black text-indigo-500 uppercase tracking-[0.3em] mb-4">Discovery</h1>
            <h2 className="text-5xl md:text-7xl font-black tracking-tighter italic uppercase">
              Search <span className="text-zinc-600 italic">"{query}"</span>
            </h2>
          </div>
          <div className="bg-zinc-900 border border-white/5 px-6 py-3 rounded-2xl">
            <span className="text-zinc-500 text-sm font-black uppercase tracking-widest leading-none">
              <span className="text-white">{results.length}</span> Results found
            </span>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-40">
            <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : results.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-6 gap-y-12">
            {results.map((movie, i) => (
              <MovieCard key={movie.id} movie={movie} index={i} />
            ))}
          </div>
        ) : (
          <div className="text-center py-40 bg-zinc-900/20 rounded-[3rem] border border-white/5">
            <div className="w-20 h-20 bg-zinc-900 rounded-full flex items-center justify-center mx-auto mb-8 shadow-2xl">
              <SearchIcon className="w-8 h-8 text-zinc-700" />
            </div>
            <p className="text-zinc-500 text-2xl font-black uppercase italic tracking-tighter">No matches found for your search</p>
            <p className="text-zinc-600 mt-2 font-medium">Try different keywords or browse our trending movies.</p>
          </div>
        )}
      </div>
    </div>
  );
}
