import { useState, useEffect } from 'react';
import { tmdb } from '../services/api';
import { Movie } from '../lib/utils';
import MovieCard from '../components/MovieCard';
import { Play, Info, TrendingUp, ChevronRight, Star } from 'lucide-react';
import { getImageUrl } from '../services/api';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

export default function Home() {
  const [trending, setTrending] = useState<Movie[]>([]);
  const [popularMovies, setPopularMovies] = useState<Movie[]>([]);
  const [popularTV, setPopularTV] = useState<Movie[]>([]);
  const [featured, setFeatured] = useState<Movie | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [trendingRes, popularMoviesRes, popularTVRes] = await Promise.all([
          tmdb.getTrending(),
          tmdb.getPopular('movie'),
          tmdb.getPopular('tv'),
        ]);

        const trendingData = trendingRes.data.results;
        setTrending(trendingData);
        setPopularMovies(popularMoviesRes.data.results);
        setPopularTV(popularTVRes.data.results);
        setFeatured(trendingData[0]);
      } catch (error) {
        console.error('Error fetching home data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="bg-[#050505] min-h-screen pb-20">
      {/* Hero Section */}
      {featured && (
        <section className="relative h-[92vh] w-full overflow-hidden">
          <div className="absolute inset-0">
            <img
              src={getImageUrl(featured.backdrop_path, 'original')}
              alt={featured.title || featured.name}
              className="w-full h-full object-cover scale-105"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/40 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent" />
          </div>

          <div className="absolute inset-0 flex items-center">
            <div className="max-w-7xl mx-auto px-6 md:px-12 w-full">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="max-w-3xl"
              >
                <div className="flex items-center gap-4 mb-8">
                  <div className="flex -space-x-2">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="w-8 h-8 rounded-full border-2 border-[#050505] overflow-hidden bg-zinc-800">
                        <img src={`https://i.pravatar.cc/100?img=${i + 10}`} alt="user" className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                  <span className="text-sm font-semibold text-zinc-400">
                    <span className="text-white font-bold">2.4k+</span> people watching now
                  </span>
                </div>

                <h1 className="text-6xl md:text-8xl font-black text-white mb-8 leading-[0.9] tracking-tighter uppercase italic">
                  {featured.title || featured.name}
                </h1>
                
                <div className="flex items-center gap-6 mb-10 text-sm font-bold text-zinc-400">
                  <span className="text-indigo-500 bg-indigo-500/10 px-3 py-1 rounded-full border border-indigo-500/20">TRENDING</span>
                  <span className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    {featured.vote_average.toFixed(1)} Rating
                  </span>
                  <span>{new Date(featured.release_date || featured.first_air_date || '').getFullYear()}</span>
                </div>

                <p className="text-xl text-zinc-300 mb-12 line-clamp-2 leading-relaxed font-medium max-w-2xl">
                  {featured.overview}
                </p>

                <div className="flex flex-wrap items-center gap-6">
                  <Link
                    to={`/watch/${featured.media_type}/${featured.id}`}
                    className="bg-indigo-600 text-white px-10 py-5 rounded-2xl font-black flex items-center gap-3 hover:bg-indigo-500 transition-all transform hover:scale-105 shadow-2xl shadow-indigo-600/20 uppercase tracking-tighter text-lg"
                  >
                    <Play className="w-7 h-7 fill-current" />
                    Start Streaming
                  </Link>
                  <Link
                    to={`/watch/${featured.media_type}/${featured.id}`}
                    className="bg-white/5 backdrop-blur-2xl text-white border border-white/10 px-10 py-5 rounded-2xl font-black flex items-center gap-3 hover:bg-white/10 transition-all uppercase tracking-tighter text-lg"
                  >
                    <Info className="w-7 h-7" />
                    View Details
                  </Link>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      )}

      {/* Content Sections */}
      <div className="max-w-7xl mx-auto px-6 md:px-12 -mt-32 relative z-10 space-y-24">
        <section>
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 className="text-sm font-black text-indigo-500 uppercase tracking-[0.3em] mb-3">Today's Picks</h2>
              <h3 className="text-4xl font-black text-white tracking-tighter italic uppercase">Trending <span className="text-zinc-600">Now</span></h3>
            </div>
            <Link to="/search" className="text-zinc-500 hover:text-white text-sm font-black uppercase tracking-widest flex items-center gap-2 transition-colors">
              Explore All <ChevronRight className="w-5 h-5" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-6 gap-y-12">
            {trending.slice(0, 12).map((movie, i) => (
              <MovieCard key={movie.id} movie={movie} index={i} />
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 className="text-sm font-black text-indigo-500 uppercase tracking-[0.3em] mb-3">Blockbusters</h2>
              <h3 className="text-4xl font-black text-white tracking-tighter italic uppercase">Popular <span className="text-zinc-600">Movies</span></h3>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-6 gap-y-12">
            {popularMovies.slice(0, 12).map((movie, i) => (
              <MovieCard key={movie.id} movie={{ ...movie, media_type: 'movie' }} index={i} />
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 className="text-sm font-black text-indigo-500 uppercase tracking-[0.3em] mb-3">Must Watch</h2>
              <h3 className="text-4xl font-black text-white tracking-tighter italic uppercase">Top <span className="text-zinc-600">Series</span></h3>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-6 gap-y-12">
            {popularTV.slice(0, 12).map((movie, i) => (
              <MovieCard key={movie.id} movie={{ ...movie, media_type: 'tv' }} index={i} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
