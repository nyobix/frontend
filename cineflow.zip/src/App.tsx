import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Watch from './pages/Watch';
import Search from './pages/Search';
import { StreamProvider } from './context/StreamContext';

export default function App() {
  return (
    <Router>
      <StreamProvider>
        <div className="min-h-screen bg-black text-white selection:bg-indigo-500/30">
          <Navbar />
          <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/watch/:type/:id" element={<Watch />} />
              <Route path="/search" element={<Search />} />
              <Route path="/movies" element={<Home />} />
              <Route path="/tv" element={<Home />} />
            </Routes>
          </main>
          
          <footer className="bg-zinc-950 border-t border-white/5 py-12 mt-20">
            <div className="max-w-7xl mx-auto px-4 md:px-8 flex flex-col md:flex-row justify-between items-center gap-8">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-xs">CP</span>
                </div>
                <span className="text-xl font-bold tracking-tighter">CINEPAL</span>
              </div>
              
              <div className="flex gap-8 text-sm text-gray-500 font-medium">
                <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
                <a href="#" className="hover:text-white transition-colors">Contact</a>
              </div>
              
              <p className="text-sm text-gray-600">
                © 2026 Cinepal. All rights reserved.
              </p>
            </div>
          </footer>
        </div>
      </StreamProvider>
    </Router>
  );
}
