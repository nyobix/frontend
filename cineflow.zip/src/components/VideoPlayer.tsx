import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import { useStream } from '../context/StreamContext';

interface VideoPlayerProps {
  url: string;
  type?: 'hls' | 'mp4' | 'mkv' | string;
  poster?: string;
}

export default function VideoPlayer({ url, type, poster }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isBuffering, setIsBuffering] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const { setIsPlayerBuffering } = useStream();

  useEffect(() => {
    setIsPlayerBuffering(isBuffering);
    return () => {
      setIsPlayerBuffering(false);
    };
  }, [isBuffering, setIsPlayerBuffering]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    setLoadError(null);
    if (!url) return;
    
    const finalUrl = url;
    
    // Reset video state
    video.pause();
    
    // Check if it's HLS (either by explicit type or by sniffing the URL)
    const isHls = type === 'hls' || url.includes('.m3u8') || url.includes('type=hls') || url.includes('data=') && url.includes('%2Em3u8');

    if (isHls) {
      if (video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = finalUrl;
      } else if (Hls.isSupported()) {
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: true,
          xhrSetup: (xhr) => {
            xhr.withCredentials = false;
          }
        });
        hls.loadSource(finalUrl);
        hls.attachMedia(video);
        hls.on(Hls.Events.ERROR, (_event, data) => {
          if (data.fatal) {
            setLoadError(`Playback error: ${data.details}`);
            switch (data.type) {
              case Hls.ErrorTypes.NETWORK_ERROR:
                hls.startLoad();
                break;
              case Hls.ErrorTypes.MEDIA_ERROR:
                hls.recoverMediaError();
                break;
              default:
                hls.destroy();
                break;
            }
          }
        });
        return () => {
          hls.destroy();
        };
      } else {
        setLoadError("HLS playback is not supported in this browser.");
      }
    } else {
      // Direct MP4/WebM
      video.src = finalUrl;
    }
  }, [url, type]);

  return (
    <div className="relative w-full h-full bg-black group overflow-hidden">
      <div className="absolute inset-0 z-20 pointer-events-none bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      {isBuffering && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/40 backdrop-blur-sm transition-all animate-in fade-in duration-300">
          <div className="flex flex-col items-center gap-4">
            <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white">Buffering</span>
          </div>
        </div>
      )}
      <video
        ref={videoRef}
        poster={poster}
        controls
        className="w-full h-full object-contain"
        playsInline
        onWaiting={() => setIsBuffering(true)}
        onPlaying={() => setIsBuffering(false)}
        onCanPlay={() => setIsBuffering(false)}
        onLoadStart={() => setIsBuffering(true)}
      />
    </div>
  );
}
