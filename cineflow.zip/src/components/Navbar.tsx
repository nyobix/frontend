import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Menu, X, Play, Film, Tv, TrendingUp, Cpu, Wifi, Server, Layers, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useExtension } from '../hooks/useExtension';
import { useStream } from '../context/StreamContext';

export default function Navbar() {
  const { isExtensionActive } = useExtension();
  const {
    isActive: isStreamActive,
    currentType,
    title: streamTitle,
    providers,
    activeProvider,
    setActiveProvider,
    sources,
    activeSource,
    setActiveSource,
    season,
    setSeason,
    episode,
    setEpisode,
    isPlayerBuffering
  } = useStream();

  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setIsMobileMenuOpen(false);
    }
  };

  const navLinks = [
    { name: 'Home', path: '/', icon: <TrendingUp className="w-4 h-4" /> },
    { name: 'Movies', path: '/movies', icon: <Film className="w-4 h-4" /> },
    { name: 'TV Shows', path: '/tv', icon: <Tv className="w-4 h-4" /> },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-black/90 backdrop-blur-md py-3 shadow-lg' : 'bg-transparent py-5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/" className="flex items-center gap-2 group shrink-0">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center group-hover:bg-indigo-500 transition-colors shadow-lg shadow-indigo-600/20">
              <Play className="w-6 h-6 text-white fill-current" />
            </div>
            <span className="text-2xl font-bold tracking-tighter text-white uppercase italic">Cine<span className="text-indigo-500">pal</span></span>
          </Link>

          {/* Connection Status Badge (Only shown if we are NOT actively playing/controlling a stream, to prevent visual clutter) */}
          {!isStreamActive && (
            <div className="hidden lg:flex items-center gap-2.5 px-3.5 py-1.5 bg-zinc-900/60 border border-white/5 rounded-2xl backdrop-blur-xl">
              {isExtensionActive ? (
                <>
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  <span className="text-[9px] uppercase tracking-[0.1em] font-black italic text-emerald-400 flex items-center gap-1.5">
                    <Wifi className="w-3 h-3" /> Residential Bypass Active
                  </span>
                </>
              ) : (
                <>
                  <span className="relative flex h-2 w-2">
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                  </span>
                  <span className="text-[9px] uppercase tracking-[0.1em] font-black italic text-indigo-400 flex items-center gap-1.5">
                    <Cpu className="w-3 h-3" /> Cloud Server Cache Pure
                  </span>
                </>
              )}
            </div>
          )}
        </div>

        {/* Desktop Nav / Stream Controls */}
        {!isStreamActive ? (
          <div className="hidden md:flex items-center gap-8">
            <div className="flex items-center gap-6">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className="text-sm font-medium text-gray-300 hover:text-white transition-colors flex items-center gap-2"
                >
                  {link.icon}
                  {link.name}
                </Link>
              ))}
            </div>

            <form onSubmit={handleSearch} className="relative group">
              <input
                type="text"
                placeholder="Search Cinepal..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-6 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 w-72 transition-all focus:w-96 focus:bg-white/10 italic font-medium"
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500 group-focus-within:text-indigo-400 transition-colors" />
            </form>
          </div>
        ) : (
          <div className="hidden md:flex items-center gap-4 bg-zinc-950/90 border border-white/10 px-5 py-2.5 rounded-[2rem] shadow-2xl backdrop-blur-xl animate-in fade-in slide-in-from-top-4 duration-300">
            {/* Media Title & Buffering Glow */}
            <div className="flex items-center gap-2.5 border-r border-white/5 pr-4 mr-2">
              <span className="relative flex h-2 w-2 shrink-0">
                {isPlayerBuffering ? (
                  <>
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                  </>
                ) : (
                  <>
                    <span className="animate-pulse absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-50"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </>
                )}
              </span>
              <span className="text-[10px] font-black uppercase tracking-wider text-zinc-300 max-w-[150px] truncate italic">
                {streamTitle || 'Loading Stream...'}
              </span>
              {isPlayerBuffering && (
                <span className="text-[8px] bg-amber-500/10 text-amber-400 px-1.5 py-0.5 rounded border border-amber-500/20 font-black tracking-widest uppercase animate-pulse">BUFFERING</span>
              )}
            </div>

            {/* Episode Controls for TV */}
            {currentType === 'tv' && (
              <div className="flex items-center gap-2 border-r border-white/5 pr-4 mr-2 select-none">
                <span className="text-[9px] text-zinc-600 font-black uppercase tracking-widest">Shift Ep</span>
                <div className="flex items-center gap-1 bg-zinc-900 border border-white/5 rounded-xl p-0.5">
                  <button 
                    onClick={() => setEpisode(Math.max(1, episode - 1))}
                    disabled={episode <= 1}
                    className="text-zinc-500 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition-colors p-1"
                    title="Previous Episode"
                  >
                    <ChevronLeft className="w-3 h-3" />
                  </button>
                  <span className="text-[9px] font-black text-indigo-400 tracking-tight whitespace-nowrap px-1.5">
                    S{season} : E{episode}
                  </span>
                  <button 
                    onClick={() => setEpisode(episode + 1)}
                    className="text-zinc-500 hover:text-white transition-colors p-1"
                    title="Next Episode"
                  >
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            )}

            {/* Server Provider Selector */}
            <div className="flex items-center gap-2 border-r border-white/5 pr-4 mr-2">
              <span className="text-[9px] text-zinc-600 font-black uppercase tracking-widest flex items-center gap-1.5">
                <Server className="w-3.5 h-3.5 text-indigo-400" /> Server
              </span>
              <select
                value={activeProvider}
                onChange={(e) => setActiveProvider(e.target.value)}
                className="bg-zinc-900 border border-white/5 rounded-xl px-2.5 py-1 text-[9px] font-black tracking-wider text-zinc-300 uppercase focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer hover:bg-zinc-800"
              >
                {providers.map((p) => (
                  <option key={p.id} value={p.id} className="bg-zinc-950 font-bold">
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Direct Qualities Selector */}
            {sources.length > 0 && (
              <div className="flex items-center gap-2">
                <span className="text-[9px] text-zinc-600 font-black uppercase tracking-widest flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-indigo-400" /> Quality
                </span>
                <select
                  value={activeSource?.url || ''}
                  onChange={(e) => {
                    const matched = sources.find((s) => s.url === e.target.value);
                    if (matched) setActiveSource(matched);
                  }}
                  className="bg-zinc-900 border border-white/5 rounded-xl px-2.5 py-1 text-[9px] font-black tracking-wider text-zinc-300 uppercase focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer hover:bg-zinc-800"
                >
                  {sources.map((s, idx) => (
                    <option key={idx} value={s.url} className="bg-zinc-950 font-bold">
                      {s.isExtension ? '📡 ' : ''}{s.quality || 'Auto'}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        )}

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white p-2"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Quick-Shift Sub-Bar (Sticky under main navbar on mobile when active) */}
      {isStreamActive && (
        <div className="md:hidden bg-zinc-950/95 border-t border-white/5 px-4 py-2.5 flex items-center justify-between gap-4 overflow-x-auto no-scrollbar backdrop-blur-md">
          <div className="flex items-center gap-1.5 shrink-0 max-w-[120px]">
            <span className={`relative flex h-1.5 w-1.5 shrink-0`}>
              <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 ${isPlayerBuffering ? 'bg-amber-400 animate-ping' : 'bg-emerald-400 animate-pulse'}`}></span>
              <span className={`relative inline-flex rounded-full h-1.5 w-1.5 ${isPlayerBuffering ? 'bg-amber-500' : 'bg-emerald-500'}`}></span>
            </span>
            <span className="text-[8px] font-black text-zinc-400 uppercase tracking-wider truncate italic">{streamTitle}</span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {currentType === 'tv' && (
              <div className="flex items-center gap-1 bg-zinc-900 border border-white/5 rounded-[0.5rem] px-1.5 py-0.5">
                <button 
                  onClick={() => setEpisode(Math.max(1, episode - 1))}
                  disabled={episode <= 1}
                  className="text-zinc-500 disabled:opacity-20 p-0.5 active:scale-95 transition-all"
                >
                  <ChevronLeft className="w-3 h-3" />
                </button>
                <span className="text-[8px] font-black text-indigo-400 whitespace-nowrap">S{season}:E{episode}</span>
                <button 
                  onClick={() => setEpisode(episode + 1)}
                  className="text-zinc-500 p-0.5 active:scale-95 transition-all"
                >
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            )}

            <select
              value={activeProvider}
              onChange={(e) => setActiveProvider(e.target.value)}
              className="bg-zinc-900 border border-white/5 rounded-[0.5rem] px-2 py-1 text-[8px] font-black text-zinc-300 uppercase focus:outline-none"
            >
              {providers.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
            
            {sources.length > 0 && (
              <select
                value={activeSource?.url || ''}
                onChange={(e) => {
                  const matched = sources.find((s) => s.url === e.target.value);
                  if (matched) setActiveSource(matched);
                }}
                className="bg-zinc-900 border border-white/5 rounded-[0.5rem] px-2 py-1 text-[8px] font-black text-zinc-300 uppercase focus:outline-none"
              >
                {sources.map((s, idx) => (
                  <option key={idx} value={s.url}>{s.quality || 'Auto'}</option>
                ))}
              </select>
            )}
          </div>
        </div>
      )}

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 bg-zinc-900 border-b border-white/10 p-4 md:hidden"
          >
            <form onSubmit={handleSearch} className="relative mb-4">
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            </form>
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-lg font-medium text-gray-300 hover:text-white flex items-center gap-3 p-2 rounded-lg hover:bg-white/5"
                >
                  {link.icon}
                  {link.name}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
