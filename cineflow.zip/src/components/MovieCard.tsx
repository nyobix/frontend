import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Play } from 'lucide-react';
import { Movie } from '../lib/utils';
import { getImageUrl } from '../services/api';
import { motion } from 'motion/react';

interface MovieCardProps {
  movie: Movie;
  index: number;
  key?: React.Key;
}

export default function MovieCard({ movie, index }: MovieCardProps) {
  const title = movie.title || movie.name;
  const releaseDate = movie.release_date || movie.first_air_date;
  const year = releaseDate ? new Date(releaseDate).getFullYear() : 'N/A';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ y: -10 }}
      className="group relative"
    >
      <Link to={`/watch/${movie.media_type || 'movie'}/${movie.id}`}>
        <div className="relative aspect-[2/3] rounded-[2rem] overflow-hidden bg-zinc-900 shadow-2xl transition-all duration-500 group-hover:shadow-[0_20px_50px_rgba(79,70,229,0.3)]">
          <img
            src={getImageUrl(movie.poster_path)}
            alt={title}
            className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110 grayscale-[0.2] group-hover:grayscale-0"
            referrerPolicy="no-referrer"
          />
          
          <div className="absolute top-4 right-4 z-20">
            <div className="bg-black/60 backdrop-blur-xl border border-white/10 px-3 py-1.5 rounded-2xl flex items-center gap-1.5">
              <Star className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500" />
              <span className="text-[10px] font-black text-white">{movie.vote_average.toFixed(1)}</span>
            </div>
          </div>

          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex flex-col justify-end p-6">
            <div className="bg-indigo-600 w-14 h-14 rounded-full flex items-center justify-center self-center mb-6 transform scale-50 group-hover:scale-100 transition-transform duration-500 shadow-2xl">
              <Play className="w-7 h-7 text-white fill-current ml-1" />
            </div>
          </div>
        </div>
        
        <div className="mt-5 px-1 px-4">
          <h3 className="text-sm font-black text-white truncate tracking-tighter uppercase italic group-hover:text-indigo-500 transition-colors">
            {title}
          </h3>
          <div className="flex items-center gap-3 mt-1.5">
            <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">{year}</span>
            <div className="w-1 h-1 rounded-full bg-zinc-800" />
            <span className="text-[10px] font-black text-indigo-500/60 uppercase tracking-widest">{movie.media_type || 'movie'}</span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
