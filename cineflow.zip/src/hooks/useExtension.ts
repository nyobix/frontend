import { useState, useEffect, useCallback } from 'react';

export interface ExtensionSource {
  url: string;
  quality?: string;
  type?: 'hls' | 'dash' | 'http' | 'mp4' | 'mkv';
  provider?: {
    id: string;
    name: string;
  };
  headers?: Record<string, string>;
}

export function useExtension() {
  const [isExtensionActive, setIsExtensionActive] = useState(false);
  const [isScraping, setIsScraping] = useState(false);
  const [scrapedSources, setScrapedSources] = useState<ExtensionSource[]>([]);
  const [scrapeError, setScrapeError] = useState<string | null>(null);

  // Quick check function
  const checkGlobalObj = useCallback(() => {
    const win = window as any;
    if (win.__CINEPRO_EXTENSION__ || win.__OMSS_EXTENSION__ || win.cineproExtension) {
      if (!isExtensionActive) {
        setIsExtensionActive(true);
      }
      return true;
    }
    return false;
  }, [isExtensionActive]);

  useEffect(() => {
    // 1. Listen for pong messages or scraped responses from the extension
    const handleMessage = (event: MessageEvent) => {
      const data = event.data;
      if (!data) return;

      // Handle Pong handshake
      if (data.type === 'CINEPRO_PONG' || data.type === 'OMSS_PONG') {
        setIsExtensionActive(true);
      }

      // Handle Scraped responses
      if (data.type === 'CINEPRO_SCRAPE_RESPONSE' || data.type === 'OMSS_SCRAPE_RESPONSE') {
        setIsScraping(false);
        if (data.payload && data.payload.sources && data.payload.sources.length > 0) {
          setScrapedSources(data.payload.sources);
          setScrapeError(null);
        } else {
          setScrapeError(data.payload?.error || 'Exhausted extension residential stream lookups.');
        }
      }
    };

    window.addEventListener('message', handleMessage);

    // Initial check
    checkGlobalObj();

    // 2. Perform regular Ping Handshake
    const pingHandshake = () => {
      window.postMessage({ type: 'CINEPRO_PING' }, '*');
      window.postMessage({ type: 'OMSS_PING' }, '*');
    };

    pingHandshake();
    const interval = setInterval(() => {
      const checked = checkGlobalObj();
      if (!checked) {
        pingHandshake();
      }
    }, 2500);

    return () => {
      window.removeEventListener('message', handleMessage);
      clearInterval(interval);
    };
  }, [checkGlobalObj]);

  // Request client-side residential scraping from extension
  const triggerExtensionScrape = useCallback((mediaType: 'movie' | 'tv', tmdbId: string, title: string, s?: number, e?: number) => {
    if (!checkGlobalObj() && !(window as any).__CINEPRO_EXTENSION_ACTIVE__) {
      setScrapeError('CinePro browser extension is not installed or active.');
      return false;
    }

    setIsScraping(true);
    setScrapedSources([]);
    setScrapeError(null);

    // Send scraping request directly to the page context
    window.postMessage({
      type: 'CINEPRO_SCRAPE_REQUEST',
      payload: {
        type: mediaType,
        id: tmdbId,
        title,
        season: s,
        episode: e,
        timestamp: Date.now()
      }
    }, '*');

    // Also dispatch a custom dom event for extensions that inject content scripts listening to events
    const customEvent = new CustomEvent('cinepro_scrape_request', {
      detail: {
        type: mediaType,
        id: tmdbId,
        title,
        season: s,
        episode: e
      }
    });
    window.dispatchEvent(customEvent);

    return true;
  }, [checkGlobalObj]);

  return {
    isExtensionActive,
    isScraping,
    scrapedSources,
    scrapeError,
    triggerExtensionScrape,
    setScrapedSources,
    setIsScraping,
    setScrapeError
  };
}
