import React, { createContext, useContext, useState, useEffect } from 'react';

export interface ProviderItem {
  id: string;
  name: string;
  icon: string;
}

export interface StreamContextType {
  isActive: boolean;
  setIsActive: (active: boolean) => void;
  currentType: 'movie' | 'tv' | null;
  setCurrentType: (type: 'movie' | 'tv' | null) => void;
  currentId: string | null;
  setCurrentId: (id: string | null) => void;
  title: string;
  setTitle: (title: string) => void;
  
  // Providers & Active Provider
  providers: ProviderItem[];
  activeProvider: string;
  setActiveProvider: (id: string) => void;
  
  // Sources & Selected Quality
  sources: any[];
  setSources: (sources: any[]) => void;
  activeSource: any;
  setActiveSource: (source: any) => void;
  
  // Series info (TV Show)
  season: number;
  setSeason: (s: number) => void;
  episode: number;
  setEpisode: (e: number) => void;
  totalSeasons: number;
  setTotalSeasons: (count: number) => void;
  
  // Buffering indicator
  isPlayerBuffering: boolean;
  setIsPlayerBuffering: (buffering: boolean) => void;
}

const StreamContext = createContext<StreamContextType | undefined>(undefined);

export function StreamProvider({ children }: { children: React.ReactNode }) {
  const [isActive, setIsActive] = useState(false);
  const [currentType, setCurrentType] = useState<'movie' | 'tv' | null>(null);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  
  const [activeProvider, setActiveProvider] = useState('vidsrc');
  const [sources, setSources] = useState<any[]>([]);
  const [activeSource, setActiveSource] = useState<any>(null);
  
  const [season, setSeason] = useState(1);
  const [episode, setEpisode] = useState(1);
  const [totalSeasons, setTotalSeasons] = useState(1);
  const [isPlayerBuffering, setIsPlayerBuffering] = useState(false);

  const providers: ProviderItem[] = [
    { id: 'vidsrc', name: 'VidSrc', icon: '⚡' },
    { id: 'vixsrc', name: 'VixSrc', icon: '🔥' },
    { id: 'vidnest', name: 'VidNest', icon: '🪹' },
    { id: 'vidrock', name: 'VidRock', icon: '🤘' },
    { id: 'videasy', name: 'VidEasy', icon: '✨' },
    { id: 'vidzee', name: 'VidZee', icon: '🌊' },
    { id: 'streammafia', name: 'MafiaEmbed', icon: '🕴️' },
    { id: 'fmovies4u', name: 'FMovies', icon: '📺' },
    { id: 'anyembed', name: 'AnyEmbed', icon: '🌐' },
    { id: 'cinesu', name: 'CineSu', icon: '💠' },
    { id: 'icefy', name: 'Icefy', icon: '❄️' },
    { id: 'popr', name: 'PopR', icon: '🍿' },
    { id: '02moviedownloader', name: '02Movie', icon: '📥' },
    { id: 'peachify', name: 'Peachify', icon: '🍑' },
  ];

  // Clean state when leaving a watch session
  useEffect(() => {
    if (!isActive) {
      setSources([]);
      setActiveSource(null);
      setIsPlayerBuffering(false);
    }
  }, [isActive]);

  return (
    <StreamContext.Provider
      value={{
        isActive,
        setIsActive,
        currentType,
        setCurrentType,
        currentId,
        setCurrentId,
        title,
        setTitle,
        providers,
        activeProvider,
        setActiveProvider,
        sources,
        setSources,
        activeSource,
        setActiveSource,
        season,
        setSeason,
        episode,
        setEpisode,
        totalSeasons,
        setTotalSeasons,
        isPlayerBuffering,
        setIsPlayerBuffering
      }}
    >
      {children}
    </StreamContext.Provider>
  );
}

export function useStream() {
  const context = useContext(StreamContext);
  if (context === undefined) {
    throw new Error('useStream must be used within a StreamProvider');
  }
  return context;
}
