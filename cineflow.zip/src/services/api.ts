import axios from 'axios';
import { createOmssClient } from '@omss/sdk';

const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const TMDB_KEY = import.meta.env.VITE_TMDB_API_KEY;

const api = axios.create({
  baseURL: TMDB_BASE_URL,
});

// Helper for TMDB params
const getParams = (params: any = {}) => {
  return { ...params, api_key: TMDB_KEY };
};

export const tmdb = {
  getTrending: (type: 'movie' | 'tv' | 'all' = 'all') => 
    api.get(`/trending/${type}/day`, { params: getParams() }),
  getPopular: (type: 'movie' | 'tv') => 
    api.get(`/${type}/popular`, { params: getParams() }),
  getDetails: (type: 'movie' | 'tv', id: string) => 
    api.get(`/${type}/${id}`, { params: getParams() }),
  getVideos: (type: 'movie' | 'tv', id: string) => 
    api.get(`/${type}/${id}/videos`, { params: getParams() }),
  search: (query: string) => 
    api.get(`/search/multi`, { params: getParams({ query }) }),
  getRecommendations: (type: 'movie' | 'tv', id: string) => 
    api.get(`/${type}/${id}/recommendations`, { params: getParams() }),
};

export const SCRAPER_BASE_URL = 'https://cinepro2-production.up.railway.app';

// Initialize OMSS Client
const omss = createOmssClient({
  baseUrl: SCRAPER_BASE_URL,
});

export const scraper = {
  getMovieSources: (id: string) => omss.getMovie(id),
  getTvSources: (id: string, season: number, episode: number) => 
    omss.getTvEpisode(id, season, episode),
  getProxiedUrl: (url: string, headers: any = {}, local = true) => {
    if (local) {
      let proxyUrl = `/api/proxy?url=${encodeURIComponent(url)}`;
      if (headers['Referer']) proxyUrl += `&referer=${encodeURIComponent(headers['Referer'])}`;
      if (headers['User-Agent']) proxyUrl += `&userAgent=${encodeURIComponent(headers['User-Agent'])}`;
      return proxyUrl;
    }

    const data = {
      url,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Referer': new URL(url).origin + '/',
        ...headers
      }
    };
    return `${SCRAPER_BASE_URL}/v1/proxy?data=${encodeURIComponent(JSON.stringify(data))}`;
  }
};

export const getImageUrl = (path: string, size: 'w500' | 'original' = 'w500') => 
  path ? `https://image.tmdb.org/t/p/${size}${path}` : 'https://via.placeholder.com/500x750?text=No+Image';
