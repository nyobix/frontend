import pLimit from 'p-limit';

/**
 * Global limiter for outbound proxy/scraper requests.
 * Limits concurrency to prevent rate-limiting or 429 errors from target servers.
 * Default: 3 concurrent requests.
 */
export const proxyLimiter = pLimit(3);

/**
 * Wraps a request in the global concurrency limiter.
 */
export async function limitedFetch<T>(task: () => Promise<T>): Promise<T> {
  return proxyLimiter(task);
}
